import math
import random

from pygame.locals import *
import pygame
from pygame import mixer

# Intialize the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((600, 600))

# Background
background = pygame.image.load('background-image.png')

# Sound
mixer.music.load("StarStreakHeros.wav")
mixer.music.play(3)
#mixer.music.play(-1)

# Caption and Icon
pygame.display.set_caption("Space Streak Hero")
icon = pygame.image.load('SS.png')
pygame.display.set_icon(icon)

# Score
score_value = 0
font = pygame.font.Font('freesansbold.ttf', 32)

# Target Score
target_score_value = 10
font = pygame.font.Font('freesansbold.ttf', 32)

textX = 10
testY = 10
textXX = 300
textYY = 10
textXXX = 85
textYYY = 250

# Player
playerImg = pygame.image.load('hero.png')
playerX = 370
playerY = 500
playerX_change = 0

def player(x, y):
    screen.blit(playerImg, (x, y))

# Metorite
metoriteImg = []
metoriteX = []
metoriteY = []
metoriteX_change = []
metoriteY_change = []
num_of_metorites = 6

# create metorites
for i in range(num_of_metorites):
    metoriteImg.append(pygame.image.load('metorite.png'))
    metoriteX.append(random.randint(0, 461))
    metoriteY.append(random.randint(50, 150))
    metoriteX_change.append(4)
    metoriteY_change.append(40)

def metorite(x, y, i):
    screen.blit(metoriteImg[i], (x, y))

# UFO
ufoImg = []
ufoX = []
ufoY = []
ufoX_change = []
ufoY_change = []
num_of_ufo = 7

# create ufo
for i in range(num_of_ufo):
    ufoImg.append(pygame.image.load('ufo.png'))
    ufoX.append(random.randint(5, 600))
    ufoY.append(random.randint(45, 100))
    ufoX_change.append(4)
    ufoY_change.append(40)

def ufo(x, y, i):
    screen.blit(ufoImg[i], (x, y))

# Star
starImg = []
starX = []
starY = []
starX_change = []
starY_change = []
num_of_stars = 3

# create stars
for i in range(num_of_stars):
    starImg.append(pygame.image.load('star.png'))
    starX.append(random.randint(4, 543))
    starY.append(random.randint(30, 95))
    starX_change.append(4)
    starY_change.append(40)

def star(x, y, i):
    screen.blit(starImg[i], (x, y))


def show_score(x, y):
    score = font.render("Score : " + str(score_value), True, (255, 255, 255))
    screen.blit(score, (x, y))

def show_target_score(x, y):
   target_score = font.render("Target Score : " + str(target_score_value), True, (255, 255, 255))
   screen.blit(target_score, (x, y))

# Bullet

# Ready - You can't see the bullet on the screen
# Fire - The bullet is currently moving

bulletImg = pygame.image.load('laser.png')
bulletX = 0
bulletY = 480
bulletX_change = 0
bulletY_change = 10
bullet_state = "ready"

# draw bullet
def fire_bullet(x, y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletImg, (x + 16, y + 10))

# collision detection, find distance between (x1,y1) and (x2,y2)
def isCollision(metoriteX, metoriteY, bulletX, bulletY):
    distance = math.sqrt(math.pow(metoriteX - bulletX, 2) + (math.pow(metoriteY - bulletY, 2)))
    if distance < 27:
        return True
    else:
        return False

def isCollision1(ufoX, ufoY, bulletX, bulletY):
    distance = math.sqrt(math.pow(ufoX - bulletX, 2) + (math.pow(ufoY - bulletY, 2)))
    if distance < 27:
        return True
    else:
        return False

def isCollision2(starX, starY, bulletX, bulletY):
    distance = math.sqrt(math.pow(starX - bulletX, 2) + (math.pow(starY - bulletY, 2)))
    if distance < 27:
        return True
    else:
        return False

def set_background():
    global background
    # RGB = Red, Green, Blue
    screen.fill((0, 0, 0))

    # Background Image
    screen.blit(background, (0, 0))

def move_bullet():
    global bulletX, bulletY, bullet_state
    # Bullet Movement
    if bulletY <= 0:
        bulletY = 480
        bullet_state = "ready"

    if bullet_state is "fire":
        fire_bullet(bulletX, bulletY)
        bulletY -= bulletY_change    

def game_input():
    global running, playerX_change, bulletX, playerX, bulletY
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # if keystroke is pressed check whether its right or left
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -5
            if event.key == pygame.K_RIGHT:
                playerX_change = 5 
            if event.key == pygame.K_SPACE:
                if bullet_state is "ready":
                    bulletSound = mixer.Sound("laser.wav")
                    bulletSound.play()
                    # Get the current x cordinate of the spaceship
                    bulletX = playerX
                    fire_bullet(bulletX, bulletY)

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0


    playerX += playerX_change
    if playerX <= 0:
        playerX = 0
    elif playerX >= 736:
        playerX = 736

def metorite_movement():
    global metoriteX, metoriteX_change, metoriteY, metoriteY_change
    # Enemy Movement
    for i in range(num_of_metorites):

        metoriteX[i] += metoriteX_change[i]
        if metoriteX[i] <= 0:
            metoriteX_change[i] = 4
            metoriteY[i] += metoriteY_change[i]
        elif metoriteX[i] >= 736:
            metoriteX_change[i] = -4
            metoriteY[i] += metoriteY_change[i]
 
        metorite(metoriteX[i], metoriteY[i], i)

def ufo_movement():
    global ufoX, ufoX_change, ufoY, ufoY_change
    # Enemy Movement
    for i in range(num_of_ufo):

        ufoX[i] += ufoX_change[i]
        if ufoX[i] <= 0:
            ufoX_change[i] = 4
            ufoY[i] += ufoY_change[i]
        elif ufoX[i] >= 736:
            ufoX_change[i] = -4
            ufoY[i] += ufoY_change[i]
 
        ufo(ufoX[i], ufoY[i], i)

def star_movement():
    global starX, starX_change, starY, starY_change
    # Enemy Movement
    for i in range(num_of_stars):

        starX[i] += starX_change[i]
        if starX[i] <= 0:
            starX_change[i] = 4
            starY[i] += starY_change[i]
        elif starX[i] >= 736:
            starX_change[i] = -4
            starY[i] += starY_change[i]
 
        star(starX[i], starY[i], i)

def collision():
    global num_of_metorites, num_of_stars, num_of_ufo, metoriteX, metoriteY, starX, starY, ufoX, ufoY, bulletX, bulletY, bullet_state, score_value
    for i in range(num_of_metorites):
        # Collision
        collision = isCollision(metoriteX[i], metoriteY[i], bulletX, bulletY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            bulletY = 480
            bullet_state = "ready"
            score_value -= 2
            metoriteX[i] = random.randint(0, 736)
            metoriteY[i] = random.randint(50, 150)
            num_of_metorites = 6

    for i in range(num_of_stars):
        # Collision
        collision = isCollision(starX[i], starY[i], bulletX, bulletY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            bulletY = 480
            bullet_state = "ready"
            score_value += 3
            starX[i] = random.randint(0, 736)
            starY[i] = random.randint(50, 150)
            num_of_stars = 3

    for i in range(num_of_ufo):
        # Collision
        collision = isCollision(ufoX[i], ufoY[i], bulletX, bulletY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            bulletY = 480
            bullet_state = "ready"
            score_value += 1
            ufoX[i] = random.randint(0, 736)
            ufoY[i] = random.randint(50, 150)
            num_of_ufo = 7

def difficulty():
    global score_value, target_score_value, num_of_metorites, num_of_stars, num_of_ufo
    if score_value == target_score_value:
       target_score_value += 10
       num_of_metorites += 7
       num_of_ufo += 6
       num_of_stars += 3

def ultimate_end(x, y):
    global score_value, num_of_metorites, num_of_stars, num_of_ufo, target_score_value, running
    if score_value == 100:
        num_of_metorites = 0
        num_of_stars = 0
        num_of_ufo = 0
        message = font.render("Great! Press A to end the Game", True, (255, 255, 255))
        screen.blit(message, (x, y))
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
              running = False


        


# Game Loop
running = True
while running:
    set_background()
    game_input() 
    metorite_movement()
    star_movement()
    ufo_movement()
    collision()
    move_bullet()
    player(playerX, playerY)
    show_score(textX, testY)
    show_target_score(textXX, textYY)
    difficulty()
    ultimate_end(textXXX, textYYY)
    pygame.display.update()
