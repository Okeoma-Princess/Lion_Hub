import math
import random

from pygame.locals import *
import pygame
from pygame import mixer

# Intialize the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((700, 600))

# Background
background = pygame.image.load('cave_background.png')

# Sound
mixer.music.load("Survival-Training-Maximum.wav")
mixer.music.play(-1)

# Caption and Icon
pygame.display.set_caption("Survival Training Maximum")
icon = pygame.image.load('Survival_Training_Maximum_Logo.png')
pygame.display.set_icon(icon)

# Score
score_value = 0
level_value = 1
lives_value = 6
font = pygame.font.Font('freesansbold.ttf', 32)

level_textX = 250
level_textY = 25

score_textX = 25
score_textY = 25

winMessageX = 30
winMessageY = 300

lives_textX = 500
lives_textY = 25

loseMessageX = 150
loseMessageY = 300

# Player
playerImg = pygame.image.load('james.png')
playerX = 370
playerY = 480
playerX_change = 0
playerY_change = 0

def player(x, y):
    screen.blit(playerImg, (x, y))

# Obstacles and loots
bolderImg = []
bolderX = []
bolderY = []
bolderX_change = []
bolderY_change = []
num_of_bolders = 6

catepilliarImg = []
catepilliarX = []
catepilliarY = []
catepilliarX_change = []
catepilliarY_change = []
num_of_catepilliars = 6

coinImg = []
coinX = []
coinY = []
coinX_change = []
coinY_change = []
num_of_coins = 7

diamondImg = []
diamondX = []
diamondY = []
diamondX_change = []
diamondY_change = []
num_of_diamonds = 4


spiderImg = []
spiderX = []
spiderY = []
spiderX_change = []
spiderY_change = []
num_of_spiders = 6

spikesImg = []
spikesX = []
spikesY = []
num_of_spikes = 6




# create enemies
for i in range(num_of_bolders):
    bolderImg.append(pygame.image.load('bolder.png'))
    bolderX.append(random.randint(0, 736))
    bolderY.append(random.randint(50, 150))
    bolderX_change.append(4)
    bolderY_change.append(40)

for i in range(num_of_catepilliars):
    catepilliarImg.append(pygame.image.load('catepilliar.png'))
    catepilliarX.append(random.randint(6, 636))
    catepilliarY.append(random.randint(50, 150))
    catepilliarX_change.append(4)
    catepilliarY_change.append(40)

for i in range(num_of_coins):
    coinImg.append(pygame.image.load('coin.png'))
    coinX.append(random.randint(12, 535))
    coinY.append(random.randint(60, 200))
    coinX_change.append(4)
    coinY_change.append(40)

for i in range(num_of_diamonds):
    diamondImg.append(pygame.image.load('diamond.png'))
    diamondX.append(random.randint(2, 435))
    diamondY.append(random.randint(100, 500))
    diamondX_change.append(4)
    diamondY_change.append(40)
    

for i in range(num_of_spiders):
    spiderImg.append(pygame.image.load('spider.png'))
    spiderX.append(random.randint(16, 636))
    spiderY.append(random.randint(120, 600))
    spiderX_change.append(4)
    spiderY_change.append(40)

for i in range(num_of_spikes):
    spikesImg.append(pygame.image.load('spikes.png'))
    spikesX.append(random.randint(14, 718))
    spikesY.append(random.randint(50, 718))
    

def bolder(x, y, i):
    screen.blit(bolderImg[i], (x, y))

def catepilliar(x, y, i):
    screen.blit(catepilliarImg[i], (x, y))

def coin(x, y, i):
    screen.blit(coinImg[i], (x, y))

def diamond(x, y, i):
    screen.blit(diamondImg[i], (x, y))

def spider(x, y, i):
    screen.blit(spiderImg[i], (x, y))

def spikes(x, y, i):
    screen.blit(spikesImg[i], (x, y))

def show_score(x, y):
    score = font.render("Score : " + str(score_value), True, (255, 255, 255))
    screen.blit(score, (x, y))

def show_lives(x, y):
    lives = font.render("Lives : " + str(lives_value), True, (255, 255, 255))
    screen.blit(lives, (x, y))

def level_increase():
    global score_value, level_value, catepilliarX, catepilliarY, catepilliar_changeX, catepilliar_changeY, num_of_catepilliars, coinX, coinY, coinX_change, coinY_change, num_of_coins, diamondX, diamondY, diamondX_change, diamondY_change, num_of_diamonds, spiderX, spiderY, num_of_spiders, spiderX_change, spiderY_change, lives_value
    if score_value >= 10:
        level_value = 2
        num_of_catepilliars = 8
        for i in range(num_of_catepilliars):
          catepilliarImg.append(pygame.image.load('catepilliar.png'))
          catepilliarX.append(random.randint(6, 636))
          catepilliarY.append(random.randint(50, 150))
          catepilliarX_change.append(4)
          catepilliarY_change.append(40)
        num_of_spiders = 8
        for i in range(num_of_spiders):
          spiderImg.append(pygame.image.load('spider.png'))
          spiderX.append(random.randint(16, 636))
          spiderY.append(random.randint(120, 600))
          spiderX_change.append(4)
          spiderY_change.append(40)

    if score_value >= 20:
        level_value = 3
        num_of_catepilliars = 10
        for i in range(num_of_catepilliars):
          catepilliarImg.append(pygame.image.load('catepilliar.png'))
          catepilliarX.append(random.randint(6, 636))
          catepilliarY.append(random.randint(50, 150))
          catepilliarX_change.append(4)
          catepilliarY_change.append(40)
        num_of_spiders = 10
        for i in range(num_of_spiders):
          spiderImg.append(pygame.image.load('spider.png'))
          spiderX.append(random.randint(16, 636))
          spiderY.append(random.randint(120, 600))
          spiderX_change.append(4)
          spiderY_change.append(40)
        num_of_coins = 8
        for i in range(num_of_coins):
          coinImg.append(pygame.image.load('coin.png'))
          coinX.append(random.randint(12, 535))
          coinY.append(random.randint(60, 200))
          coinX_change.append(4)
          coinY_change.append(40)
        num_of_diamonds = 6
        for i in range(num_of_diamonds):
          diamondImg.append(pygame.image.load('diamond.png'))
          diamondX.append(random.randint(2, 435))
          diamondY.append(random.randint(100, 500))
          diamondX_change.append(4)
          diamondY_change.append(40)
    if score_value >= 30:
        level_value = 4
        num_of_catepilliars = 15
        for i in range(num_of_catepilliars):
          catepilliarImg.append(pygame.image.load('catepilliar.png'))
          catepilliarX.append(random.randint(6, 636))
          catepilliarY.append(random.randint(50, 150))
          catepilliarX_change.append(4)
          catepilliarY_change.append(40)
        num_of_spiders = 15
        for i in range(num_of_spiders):
          spiderImg.append(pygame.image.load('spider.png'))
          spiderX.append(random.randint(16, 636))
          spiderY.append(random.randint(120, 600))
          spiderX_change.append(4)
          spiderY_change.append(40)
        num_of_coins = 8
        for i in range(num_of_coins):
          coinImg.append(pygame.image.load('coin.png'))
          coinX.append(random.randint(12, 535))
          coinY.append(random.randint(60, 200))
          coinX_change.append(4)
          coinY_change.append(40)
        num_of_diamonds = 6
        for i in range(num_of_diamonds):
          diamondImg.append(pygame.image.load('diamond.png'))
          diamondX.append(random.randint(2, 435))
          diamondY.append(random.randint(100, 500))
          diamondX_change.append(4)
          diamondY_change.append(40)
    if score_value >= 40:
      level_value = 5
      num_of_catepilliars = 20
      for i in range(num_of_catepilliars):
          catepilliarImg.append(pygame.image.load('catepilliar.png'))
          catepilliarX.append(random.randint(6, 636))
          catepilliarY.append(random.randint(50, 150))
          catepilliarX_change.append(4)
          catepilliarY_change.append(40)
      num_of_spiders = 20
      for i in range(num_of_spiders):
          spiderImg.append(pygame.image.load('spider.png'))
          spiderX.append(random.randint(16, 636))
          spiderY.append(random.randint(120, 600))
          spiderX_change.append(4)
          spiderY_change.append(40)
      num_of_coins = 10
      for i in range(num_of_coins):
          coinImg.append(pygame.image.load('coin.png'))
          coinX.append(random.randint(12, 535))
          coinY.append(random.randint(60, 200))
          coinX_change.append(4)
          coinY_change.append(40)
      num_of_diamonds = 8
      for i in range(num_of_diamonds):
          diamondImg.append(pygame.image.load('diamond.png'))
          diamondX.append(random.randint(2, 435))
          diamondY.append(random.randint(100, 500))
          diamondX_change.append(4)
          diamondY_change.append(40)
def win_message(x, y):
    global num_of_catepilliars, num_of_coins, num_of_diamonds, num_of_spiders
    if score_value >= 50:
        num_of_catepilliars = 0
        num_of_coins = 0
        num_of_diamonds = 0
        num_of_spiders = 0
        message = font.render("Great! You have completed all the levels.", True, (255, 255, 255))
        screen.blit(message, (x, y))



def show_level(x, y):
    level = font.render("Level : " +str(level_value), True, (255, 255, 255))
    screen.blit(level, (x, y))




def isCollisionBolder(bolderX, bolderY, playerX, playerY, num_of_bolders):
    distance = math.sqrt(math.pow(bolderX - playerX, 2) + (math.pow(bolderY - playerY, 2)))
    if distance < 27:
        return True
    else:
        return False

def isCollisionCatepilliar(catepilliarX, catepilliarY, playerX, playerY):
    distance = math.sqrt(math.pow(catepilliarX - playerX, 2) + (math.pow(catepilliarY - playerY, 2)))
    if distance < 27:
        return True
    else:
        return False


def isCollisionCoin(coinX, coinY, playerX, playerY):
    distance = math.sqrt(math.pow(coinX - playerX, 2) + (math.pow(coinY - playerY, 2)))
    if distance < 27:
        return True
    else:
        return False


def isCollisionDiamond(diamondX, diamondY, playerX, playerY):
    distance = math.sqrt(math.pow(diamondX - playerX, 2) + (math.pow(diamondY - playerY, 2)))
    if distance < 27:
        return True
    else:
        return False


def isCollisionSpider(spiderX, spiderY, playerX, playerY):
    distance = math.sqrt(math.pow(spiderX - playerX, 2) + (math.pow(spiderY - playerY, 2)))
    if distance < 27:
        return True
    else:
        return False


def isCollisionSpikes(spikesX, spikesY, playerX, playerY):
    distance = math.sqrt(math.pow(spikesX - playerX, 2) + (math.pow(spikesY - playerY, 2)))
    if distance < 27:
        return True
    else:
        return False

def set_background():
    global background
    # RGB = Red, Green, Blue
    screen.fill((0, 0, 0))

    # Background Image
    screen.blit(background, (0, 0))


def game_input():
    global running, playerX_change, playerY_change, playerX, playerY
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # if keystroke is pressed check whether its right or left
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -5
            if event.key == pygame.K_RIGHT:
                playerX_change = 5
            if event.key == pygame.K_UP:
                playerY_change = -5
            if event.key == pygame.K_DOWN:
                playerY_change = 5
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT or event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                playerX_change = 0
                playerY_change = 0

    playerX += playerX_change
    if playerX <= 0:
        playerX = 0
    elif playerX >= 736:
        playerX = 736

    playerY += playerY_change
    if playerY <= 0:
        playerY = 0
    elif playerY >= 736:
        playerY = 736

def bolder_movement():
    global bolderX, bolderX_change, bolderY, bolderY_change
    # Enemy Movement
    for i in range(num_of_bolders):

        bolderX[i] += bolderX_change[i]
        if bolderX[i] <= 0:
            bolderX_change[i] = 4
            bolderY[i] += bolderY_change[i]
        elif bolderX[i] >= 736:
            bolderX_change[i] = -4
            bolderY[i] += bolderY_change[i]
 
        bolder(bolderX[i], bolderY[i], i)

def catepilliar_movement():
    global catepilliarX, catepilliarX_change, catepilliarY, catepilliarY_change
    # Enemy Movement
    for i in range(num_of_catepilliars):

        catepilliarX[i] += catepilliarX_change[i]
        if catepilliarX[i] <= 0:
            catepilliarX_change[i] = 4
            catepilliarY[i] += catepilliarY_change[i]
        elif catepilliarX[i] >= 733:
            catepilliarX_change[i] = -4
            catepilliarY[i] += catepilliarY_change[i]
 
        catepilliar(catepilliarX[i], catepilliarY[i], i)

def coin_movement():
    global coinX, coinX_change, coinY, coinY_change
    # Enemy Movement
    for i in range(num_of_coins):

        coinX[i] += coinX_change[i]
        if coinX[i] <= 0:
            coinX_change[i] = 4
            coinY[i] += coinY_change[i]
        elif coinX[i] >= 730:
            coinX_change[i] = -4
            coinY[i] += coinY_change[i]
 
        coin(coinX[i], coinY[i], i)

def diamond_movement():
    global diamondX, diamondX_change, diamondY, diamondY_change
    # Enemy Movement
    for i in range(num_of_diamonds):

        diamondX[i] += diamondX_change[i]
        if diamondX[i] <= 0:
            diamondX_change[i] = 4
            diamondY[i] += diamondY_change[i]
        elif diamondX[i] >= 727:
            diamondX_change[i] = -4
            diamondY[i] += diamondY_change[i]
 
        diamond(diamondX[i], diamondY[i], i)
        
def spider_movement():
    global spiderX, spiderX_change, spiderY, spiderY_change
    # Enemy Movement
    for i in range(num_of_spiders):

        spiderX[i] += spiderX_change[i]
        if spiderX[i] <= 0:
            spiderX_change[i] = 4
            spiderY[i] += spiderY_change[i]
        elif spiderX[i] >= 727:
            spiderX_change[i] = -4
            spiderY[i] += spiderY_change[i]
 
        spider(spiderX[i], spiderY[i], i)

def collisionBolder():
    global num_of_bolders, bolderX, bolderY, playerX, playerY, score_value
    for i in range(num_of_bolders):
        # Collision
        collision = isCollisionBolder(bolderX[i], bolderY[i], num_of_bolders, playerX, playerY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            score_value += -1
            bolderX[i] = random.randint(0, 736)
            bolderY[i] = random.randint(50, 150)

def collisionCatepilliar():
    global num_of_catepilliars, catepilliarX, catepilliarY, playerX, playerY, lives_value
    for i in range(num_of_catepilliars):
        # Collision
        collision = isCollisionCatepilliar(catepilliarX[i], catepilliarY[i], playerX, playerY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            lives_value -= 1
            catepilliarX[i] = random.randint(3, 733)
            catepilliarY[i] = random.randint(51, 151)

def collisionCoin():
    global num_of_coins, coinX, coinY, playerX, playerY, score_value
    for i in range(num_of_coins):
        # Collision
        collision = isCollisionCoin(coinX[i], coinY[i], playerX, playerY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            score_value += 1
            coinX[i] = random.randint(6, 730)
            coinY[i] = random.randint(52, 152)

def collisionDiamond():
    global num_of_diamonds, diamondX, diamondY, playerX, playerY, score_value
    for i in range(num_of_diamonds):
        # Collision
        collision = isCollisionDiamond(diamondX[i], diamondY[i], playerX, playerY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            score_value += 3
            diamondX[i] = random.randint(9, 727)
            diamondY[i] = random.randint(53, 153)

def collisionSpider():
    global num_of_spiders, spiderX, spiderY, playerX, playerY, lives_value
    for i in range(num_of_spiders):
        # Collision
        collision = isCollisionSpider(spiderX[i], spiderY[i], playerX, playerY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            lives_value -= 1
            spiderX[i] = random.randint(12, 724)
            spiderY[i] = random.randint(54, 154)
def noLives(x, y):
    global num_of_catepilliars, num_of_spiders, num_of_coins, num_of_diamonds, lives_value
    if lives_value == 0:
        num_of_spiders = 0
        num_of_coins = 0
        num_of_diamonds = 0
        num_of_catepilliars = 0
        message1 = font.render("Game Over! Try Again!", True, (255, 255, 255))
        screen.blit(message1, (x, y))

# Game Loop
running = True
while running:
    set_background()
    game_input() 
    catepilliar_movement()
    coin_movement()
    diamond_movement()
    spider_movement()
    collisionCatepilliar()
    collisionCoin()
    collisionDiamond()
    collisionSpider()
    player(playerX, playerY)
    show_score(score_textX, score_textY)
    show_level(level_textX, level_textY)
    level_increase()
    win_message(winMessageX, winMessageY)
    noLives(loseMessageX, loseMessageY)
    show_lives(lives_textX, lives_textY)
    pygame.display.update()
