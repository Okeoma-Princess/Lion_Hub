import math
import random

from pygame.locals import *
import pygame
from pygame import mixer

# Intialize the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((800, 600))

# Background
background = pygame.image.load('background.png')

# Sound
mixer.music.load("Super-Race-Challenge-Song.wav")
mixer.music.play(-1)

# Caption and Icon
pygame.display.set_caption("Speedy Race Challenge")
icon = pygame.image.load('speedy_race_challenge.png')
pygame.display.set_icon(icon)

# Score
score_value = 0
score1_value  = 0
value = 10
font = pygame.font.Font('freesansbold.ttf', 32)

pl1textX = 10
pl1textY = 10

pl2textX = 500
pl2textY = 10

timer_textX = 300
timer_textY = 550

messageX = 200
messageY = 300

# Timer
timer_value = 1800
num_of_deduct = 1
font = pygame.font.Font('freesansbold.ttf', 32)

# Player 1
player1Img = pygame.image.load('player1.png')
player1X = 30
player1Y = 25
player1X_change = 0

# Player 2
player2Img = pygame.image.load('player2.png')
player2X = 30
player2Y = 330
player2X_change = 0

def player1(x, y):
    screen.blit(player1Img, (x, y))

def player2(x, y):
    screen.blit(player2Img, (x,y))

#Flag Image
flagImg = pygame.image.load('finish_flag.png')
flagX = 720
flagY = 50


#Flag1 Image
flag1Img = pygame.image.load('finish_flag1.png')
flag1X = 720
flag1Y = 350

def flag(x, y):
    screen.blit(flagImg, (x, y))

def flag1(x, y):
    screen.blit(flag1Img, (x, y))

def show_score_player1(x, y):
    score = font.render("Player 1 Score : " + str(score_value), True, (255, 255, 255))
    screen.blit(score, (x, y))

def show_score_player2(x, y):
    score1 = font.render("Player 2 Score: " + str(score1_value), True, (255, 255, 255))
    screen.blit(score1, (x, y))

def show_timer(x, y):
    keep_time = font.render("Timer: "+ str(timer_value), True, (255, 255, 255))
    screen.blit(keep_time, (x, y))

#Bad Coins
coinImg = []
coinX = []
coinY = []
coinX_change = []
coinY_change = []
num_of_coins = 25

for i in range(num_of_coins):
    coinImg.append(pygame.image.load('coin.png'))
    coinX.append(random.randint(0, 736))
    coinY.append(random.randint(50, 450))
    coinX_change.append(4)
    coinY_change.append(40)

def coin(x, y, i):
    screen.blit(coinImg[i], (x, y))

def isCollisionCoin(coinX, coinY, player1X, player1Y, num_of_coins):
    distance = math.sqrt(math.pow(coinX - player1X, 2) + (math.pow(coinY - player1Y, 2)))
    if distance < 27:
        return True
    else:
        return False

def isCollisionCoin1(coinX, coinY, player2X, player2Y, num_of_coins):
    distance = math.sqrt(math.pow(coinX - player2X, 2) + (math.pow(coinY - player2Y, 2)))
    if distance < 27:
        return True
    else:
        return False

# collision detection, find distance between (x1,y1) and (x2,y2)
def isCollision(player1X, player1Y, flagX, flagY):
    distance1 = math.sqrt(math.pow(flagX - player1X, 2) + (math.pow(flagY - player1Y, 2)))
    if distance1 < 27:
        return True
    else:
        return False

def isCollision2(player2X, player2Y, flag1X, flag1Y):
    distance2 = math.sqrt(math.pow(flag1X - player2X, 2) + (math.pow(flag1Y - player2Y, 2)))
    if distance2 < 27:
        return True
    else:
        return False

def set_background():
    global background
    # RGB = Red, Green, Blue
    screen.fill((0, 0, 0))

    # Background Image
    screen.blit(background, (0, 0))

def game_input():
    global running, player1X_change, player1X, flagX, player2X, flagY, player2X_change, player2X, score_value, timer_value
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # if keystroke is pressed check whether its right or left
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player1X_change = -5
            if event.key == pygame.K_RIGHT:
                player1X_change = 5

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                player2X_change = -5
            if event.key == pygame.K_d:
                player2X_change = 5
        
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                player1X_change = 0

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a or event.key == pygame.K_d:
                player2X_change = 0 
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                    pygame.quit()
                    exit()

    player1X += player1X_change
    if player1X <= 0:
        player1X = 0
    elif player1X >= 736:
        player1X = 736

    player2X += player2X_change
    if player2X <= 0:
        player2X = 0
    elif player2X >= 736:
        player2X = 736

def coin_movement():
    global coinX, coinX_change, coinY, coinY_change
    # Enemy Movement
    for i in range(num_of_coins):

        coinX[i] += coinX_change[i]
        if coinX[i] <= 0:
            coinX_change[i] = 4
            coinY[i] += coinY_change[i]
        elif coinX[i] >= 730:
            coinX_change[i] = -4
            coinY[i] += coinY_change[i]
 
        coin(coinX[i], coinY[i], i)

def coinCollision():
    global coinX, coinY, player1X, player1Y, score_value
    for i in range(num_of_coins):
        collision = isCollisionCoin(coinX[i], coinY[i], player1X, player1Y, num_of_coins)
        if collision:
            score_value -= 1
            coinX[i] = random.randint(9, 727)
            coinY[i] = random.randint(53, 153)

def coinCollision1():
    global coinX, coinY, player1X, player1Y, score_value
    for i in range(num_of_coins):
        collision = isCollisionCoin1(coinX[i], coinY[i], player2X, player2Y, num_of_coins)
        if collision:
            score1_value -= 1
            coinX[i] = random.randint(9, 727)
            coinY[i] = random.randint(53, 153)

def collision():
    global  flag1X, flag1Y, player1X, player1Y, score_value
        # Collision
    collision = isCollision(flagX, flagY, player1X, player1Y)
    if collision:
         point = mixer.Sound('Point.mp3')
         point.play()
         score_value += 1
         player1X = 30

def collision1():
    global  flag1X, flag1Y, player2X, player2Y, score1_value
        # Collision
    collision = isCollision2(flag1X, flag1Y, player2X, player2Y)
    if collision:
        point = mixer.Sound('Point.mp3')
        point.play()
        score1_value += 1
        player2X = 30

def timer_game():
    global num_of_deduct, timer_value
    if timer_value != 0:
      for i in range(num_of_deduct):
         timer_value -= 1
    else:
             timer_value == 0

def timer_over(x, y):
    global score_value, score1_value, timer_value
    if timer_value == 0:
        if score_value > score1_value:
            message = font.render("Player 1 Wins, Press Q to quit", True, (0, 255, 0))
            screen.blit(message, (x, y))
        elif score1_value > score_value:
            message1 = font.render("Player 2 Wins, Press Q to quit", True, (0, 255, 0))
            screen.blit(message1, (x, y))
        else:
            message2 = font.render("It is a tie, Press Q to quit", True, (0, 255, 0))
            screen.blit(message2, (x, y))


# Game Loop
running = True
while running:
    set_background()
    game_input() 
    collision()
    collision1()
    player1(player1X, player1Y)
    player2(player2X, player2Y)
    show_score_player1(pl1textX, pl1textY)
    show_score_player2(pl2textX, pl2textY)
    flag1(flag1X, flag1Y)
    flag(flagX, flagY)
    timer_game()
    show_timer(timer_textX, timer_textY)
    timer_over(messageX, messageY)
    coin_movement()
    coinCollision()
    pygame.display.update()
